<?php include 'includes/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Barang</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Tambah Barang</h1>
    <form action="" method="POST">
        <label for="nama_barang">Nama Barang:</label>
        <input type="text" id="nama_barang" name="nama_barang" required>

        <label for="id_kategori">Kategori:</label>
        <select id="id_kategori" name="id_kategori" required>
            <?php
            $sql = "SELECT * FROM Kategori";
            $result = $conn->query($sql);
            while ($row = $result->fetch_assoc()) {
                echo "<option value='" . $row['id_kategori'] . "'>" . $row['nama_kategori'] . "</option>";
            }
            ?>
        </select>

        <label for="harga_beli">Harga Beli:</label>
        <input type="number" id="harga_beli" name="harga_beli" step="0.01" required>

        <label for="harga_jual">Harga Jual:</label>
        <input type="number" id="harga_jual" name="harga_jual" step="0.01" required>

        <label for="stok">Stok:</label>
        <input type="number" id="stok" name="stok" required>

        <button type="submit" name="submit">Simpan</button>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nama_barang = $_POST['nama_barang'];
        $id_kategori = $_POST['id_kategori'];
        $harga_beli = $_POST['harga_beli'];
        $harga_jual = $_POST['harga_jual'];
        $stok = $_POST['stok'];

        $sql = "INSERT INTO Barang (nama_barang, id_kategori, harga_beli, harga_jual, stok)
                VALUES ('$nama_barang', '$id_kategori', '$harga_beli', '$harga_jual', '$stok')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>Barang berhasil ditambahkan!</p>";
        } else {
            echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
        }
    }
    ?>
</body>
</html>