<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistem Persediaan</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Sistem Persediaan Barang</h1>
    <nav>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="tambah_barang.php">Tambah Barang</a></li>
            <li><a href="transaksi_masuk.php">Transaksi Masuk</a></li>
            <li><a href="transaksi_keluar.php">Transaksi Keluar</a></li>
            <li><a href="lihat_barang.php">Lihat Barang</a></li>
        </ul>
    </nav>
</body>
</html>
<nav>
    <ul>
        <li><a href="index.php">Home</a></li>
        <li><a href="tambah_barang.php">Tambah Barang</a></li>
        <li><a href="tambah_kategori.php">Tambah Kategori</a></li>
        <li><a href="transaksi_masuk.php">Transaksi Masuk</a></li>
        <li><a href="transaksi_keluar.php">Transaksi Keluar</a></li>
        <li><a href="lihat_barang.php">Lihat Barang</a></li>
        <li><a href="lihat_kategori.php">Lihat Kategori</a></li>
    </ul>
</nav>