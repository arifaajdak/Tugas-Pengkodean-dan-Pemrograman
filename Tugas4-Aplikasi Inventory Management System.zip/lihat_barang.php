<?php include 'includes/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lihat Barang</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Daftar Barang</h1>
    <table border="1">
        <tr>
            <th>ID Barang</th>
            <th>Nama Barang</th>
            <th>Kategori</th>
            <th>Harga Beli</th>
            <th>Harga Jual</th>
            <th>Stok</th>
        </tr>
        <?php
        $sql = "SELECT b.id_barang, b.nama_barang, k.nama_kategori, b.harga_beli, b.harga_jual, b.stok
                FROM Barang b
                JOIN Kategori k ON b.id_kategori = k.id_kategori";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['id_barang'] . "</td>
                        <td>" . $row['nama_barang'] . "</td>
                        <td>" . $row['nama_kategori'] . "</td>
                        <td>" . $row['harga_beli'] . "</td>
                        <td>" . $row['harga_jual'] . "</td>
                        <td>" . $row['stok'] . "</td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='6'>Tidak ada data barang.</td></tr>";
        }
        ?>
    </table>
</body>
</html>