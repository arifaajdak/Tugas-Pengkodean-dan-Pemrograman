<?php include 'includes/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Tambah Kategori</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Tambah Kategori</h1>
    <form action="" method="POST">
        <label for="nama_kategori">Nama Kategori:</label>
        <input type="text" id="nama_kategori" name="nama_kategori" required>

        <button type="submit" name="submit">Simpan</button>
    </form>

    <?php
    if (isset($_POST['submit'])) {
        $nama_kategori = $_POST['nama_kategori'];

        $sql = "INSERT INTO Kategori (nama_kategori) VALUES ('$nama_kategori')";

        if ($conn->query($sql) === TRUE) {
            echo "<p>Kategori berhasil ditambahkan!</p>";
        } else {
            echo "<p>Error: " . $sql . "<br>" . $conn->error . "</p>";
        }
    }
    ?>
</body>
</html>