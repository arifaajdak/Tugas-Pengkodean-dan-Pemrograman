<?php include 'includes/db.php'; ?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Daftar Kategori</title>
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
    <h1>Daftar Kategori</h1>
    <table border="1">
        <tr>
            <th>ID Kategori</th>
            <th>Nama Kategori</th>
            <th>Aksi</th>
        </tr>
        <?php
        $sql = "SELECT * FROM Kategori";
        $result = $conn->query($sql);

        if ($result->num_rows > 0) {
            while ($row = $result->fetch_assoc()) {
                echo "<tr>
                        <td>" . $row['id_kategori'] . "</td>
                        <td>" . $row['nama_kategori'] . "</td>
                        <td>
                            <a href='hapus_kategori.php?id=" . $row['id_kategori'] . "'>Hapus</a>
                        </td>
                      </tr>";
            }
        } else {
            echo "<tr><td colspan='3'>Tidak ada data kategori.</td></tr>";
        }
    ?>
    </table>
</body>
</html>