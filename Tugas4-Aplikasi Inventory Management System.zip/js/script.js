// Validasi Form
document.addEventListener("DOMContentLoaded", function () {
    const forms = document.querySelectorAll("form");

    forms.forEach(form => {
        form.addEventListener("submit", function (event) {
            const inputs = form.querySelectorAll("input, select");
            let isValid = true;

            inputs.forEach(input => {
                if (!input.value.trim()) {
                    isValid = false;
                    alert(`Field "${input.previousElementSibling.textContent}" tidak boleh kosong!`);
                }
            });

            if (!isValid) {
                event.preventDefault(); // Mencegah pengiriman form jika ada field kosong
            }
        });
    });
});

// Fitur Tambahan: Konfirmasi Hapus Data
function confirmDelete(url) {
    if (confirm("Apakah Anda yakin ingin menghapus data ini?")) {
        window.location.href = url;
    }
}